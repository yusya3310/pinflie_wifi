package com.pinfile.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int PICK = 1;
    private static PinServer server;
    private WebView web;
    private ValueCallback<Uri[]> chooser;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            if (server == null) { server = new PinServer(getApplicationContext(), 8787); server.start(); }
        } catch (Exception e) {
            TextView t = new TextView(this); t.setText("PinFile 無法啟動：" + e.getMessage()); t.setPadding(40, 80, 40, 40);
            setContentView(t); return;
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(Intent.createChooser(i, "選擇檔案"), PICK); }
                catch (Exception e) { chooser = null; return false; }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("http://localhost:8787/");
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        if (req != PICK || chooser == null) return;
        Uri[] out = null;
        if (res == RESULT_OK && d != null) {
            if (d.getClipData() != null) {
                out = new Uri[d.getClipData().getItemCount()];
                for (int i = 0; i < out.length; i++) out[i] = d.getClipData().getItemAt(i).getUri();
            } else if (d.getData() != null) out = new Uri[]{d.getData()};
        }
        chooser.onReceiveValue(out); chooser = null;
    }

    @Override public void onBackPressed() { moveTaskToBack(true); }
}
