package com.pinfile.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Java 版 PinFile 伺服器：與 server.js 相同的 API，網頁介面共用同一份 index.html。 */
public class PinServer {
    static final int DISCOVERY_PORT = 41234;
    static final long REQUEST_TTL = 60_000;
    static final int MAX_FILES = 1000;

    final Context ctx;
    final int port;
    final String name = Build.MODEL == null ? "Android" : Build.MODEL;
    final String id = UUID.randomUUID().toString();
    final ServerSocket server;
    final ExecutorService pool = Executors.newCachedThreadPool();
    volatile boolean receiving = false;
    final Map<String, Req> requests = new ConcurrentHashMap<>();
    final Map<String, Peer> peers = new ConcurrentHashMap<>();
    DatagramSocket udp;
    WifiManager.MulticastLock lock;

    static class Peer { String id, name, ip; int port; long seen; }
    static class FileInfo { String name; long size; volatile long received; volatile boolean done, active; Uri uri; }
    static class Req {
        String id, from, fromIp; volatile String status = "pending"; long createdAt; List<FileInfo> files = new ArrayList<>();
    }

    PinServer(Context c, int port) throws Exception {
        this.ctx = c; this.port = port;
        server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new java.net.InetSocketAddress(port));
    }

    void start() {
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            lock = wm.createMulticastLock("pinfile"); lock.setReferenceCounted(false); lock.acquire();
        } catch (Exception ignored) {}
        try {
            udp = new DatagramSocket(null);
            udp.setReuseAddress(true);
            udp.bind(new java.net.InetSocketAddress(DISCOVERY_PORT));
            udp.setBroadcast(true);
            pool.execute(this::udpLoop);
        } catch (Exception e) { udp = null; }
        pool.execute(() -> { // 定時廣播與清理
            while (true) {
                try { Thread.sleep(1000); } catch (InterruptedException e) { return; }
                long now = System.currentTimeMillis();
                for (Peer p : peers.values()) if (now - p.seen > 7000) peers.remove(p.id);
                for (Req r : requests.values()) if (r.status.equals("pending") && now - r.createdAt > REQUEST_TTL) r.status = "expired";
                if (receiving && (now / 1000) % 2 == 0) announce();
            }
        });
        pool.execute(() -> { // 主動掃描同網段（不依賴 UDP 廣播）
            while (true) {
                try { scan(); Thread.sleep(4000); } catch (InterruptedException e) { return; } catch (Exception ignored) {}
            }
        });
        pool.execute(() -> {
            while (true) {
                try { final Socket s = server.accept(); pool.execute(() -> handle(s)); }
                catch (Exception e) { return; }
            }
        });
    }

    // ---------- 裝置探索 ----------
    final ExecutorService scanPool = Executors.newFixedThreadPool(48);

    void scan() throws InterruptedException {
        List<Callable<Void>> jobs = new ArrayList<>();
        for (String ip : localIPs()) {
            final String prefix = ip.substring(0, ip.lastIndexOf('.') + 1);
            for (int i = 1; i < 255; i++) {
                final String host = prefix + i;
                if (host.equals(ip)) continue;
                jobs.add(() -> { probe(host); return null; });
            }
        }
        scanPool.invokeAll(jobs);
    }

    void probe(String host) {
        try (Socket s = new Socket()) {
            s.connect(new java.net.InetSocketAddress(host, port), 400);
            s.setSoTimeout(1500);
            OutputStream o = s.getOutputStream();
            o.write(("GET /api/hello HTTP/1.1\r\nHost: " + host + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            o.flush();
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[2048]; int n;
            InputStream in = s.getInputStream();
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            String resp = b.toString("UTF-8");
            int i = resp.indexOf("\r\n\r\n");
            if (i < 0) return;
            JSONObject m = new JSONObject(resp.substring(i + 4));
            if (!"pinfile".equals(m.optString("app")) || id.equals(m.optString("id"))) return;
            String pid = m.getString("id");
            if (m.optBoolean("receiving")) {
                Peer p = new Peer(); p.id = pid; p.name = trunc(m.optString("name"), 60); p.ip = host; p.port = m.getInt("port"); p.seen = System.currentTimeMillis();
                peers.put(pid, p);
            } else peers.remove(pid);
        } catch (Exception ignored) {}
    }
    void udpLoop() {
        byte[] buf = new byte[2048];
        while (true) {
            try {
                DatagramPacket pk = new DatagramPacket(buf, buf.length);
                udp.receive(pk);
                JSONObject m = new JSONObject(new String(pk.getData(), 0, pk.getLength(), StandardCharsets.UTF_8));
                if (!"pinfile".equals(m.optString("app")) || id.equals(m.optString("id"))) continue;
                String pid = m.getString("id");
                if (m.optBoolean("receiving")) {
                    Peer p = new Peer(); p.id = pid; p.name = trunc(m.optString("name"), 60);
                    p.ip = pk.getAddress().getHostAddress(); p.port = m.getInt("port"); p.seen = System.currentTimeMillis();
                    peers.put(pid, p);
                } else peers.remove(pid);
            } catch (Exception e) { if (udp == null || udp.isClosed()) return; }
        }
    }

    void announce() {
        if (udp == null) return;
        try {
            JSONObject o = new JSONObject();
            o.put("app", "pinfile").put("id", id).put("name", name).put("port", port).put("receiving", receiving);
            byte[] b = o.toString().getBytes(StandardCharsets.UTF_8);
            Set<String> targets = new LinkedHashSet<>();
            targets.add("255.255.255.255");
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses())
                    if (ia.getBroadcast() != null) targets.add(ia.getBroadcast().getHostAddress());
            }
            for (String t : targets) {
                try { udp.send(new DatagramPacket(b, b.length, InetAddress.getByName(t), DISCOVERY_PORT)); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    List<String> localIPs() {
        List<String> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses()))
                    if (a instanceof java.net.Inet4Address && !a.isLoopbackAddress()) out.add(a.getHostAddress());
            }
        } catch (Exception ignored) {}
        return out;
    }

    // ---------- 工具 ----------
    static String trunc(String s, int n) { return s.length() > n ? s.substring(0, n) : s; }

    static final Pattern RESERVED = Pattern.compile("^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\\..*)?$", Pattern.CASE_INSENSITIVE);
    static String safeName(String name) {
        String n = name.replace('\\', '/');
        n = n.substring(n.lastIndexOf('/') + 1);
        n = n.replaceAll("[<>:\"/\\\\|?*\\x00-\\x1f]", "_").replaceAll("[. ]+$", "");
        if (n.length() > 200) n = n.substring(0, 200);
        if (n.isEmpty() || RESERVED.matcher(n).matches()) n = "_" + n;
        return n.isEmpty() ? "file" : n;
    }

    JSONObject publicReq(Req r) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", r.id).put("from", r.from).put("fromIp", r.fromIp).put("status", r.status).put("createdAt", r.createdAt);
        JSONArray fs = new JSONArray();
        for (FileInfo f : r.files) fs.put(new JSONObject().put("name", f.name).put("size", f.size).put("received", f.received).put("done", f.done));
        return o.put("files", fs);
    }

    // ---------- HTTP ----------
    static class Http {
        String method, path, host = ""; Map<String, String> q = new HashMap<>(), h = new HashMap<>();
        InputStream in; OutputStream out; String remote; boolean cors; boolean remoteLoopback;
    }

    void send(Http r, int code, String type, byte[] body) throws Exception {
        String reason = code == 200 ? "OK" : code == 204 ? "No Content" : "Error";
        StringBuilder sb = new StringBuilder("HTTP/1.1 " + code + " " + reason + "\r\n");
        sb.append("Content-Type: ").append(type).append("\r\nContent-Length: ").append(body.length).append("\r\nConnection: close\r\n");
        if (r.cors) {
            sb.append("Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: content-type\r\n");
            sb.append("Access-Control-Allow-Methods: GET,POST,OPTIONS\r\nAccess-Control-Allow-Private-Network: true\r\n");
        }
        if (type.startsWith("text/html")) sb.append("Cache-Control: no-store\r\n");
        sb.append("\r\n");
        r.out.write(sb.toString().getBytes(StandardCharsets.UTF_8));
        r.out.write(body);
        r.out.flush();
    }
    void json(Http r, int code, Object o) throws Exception { send(r, code, "application/json; charset=utf-8", o.toString().getBytes(StandardCharsets.UTF_8)); }
    void err(Http r, int code, String msg) throws Exception { json(r, code, new JSONObject().put("error", msg)); }

    static String readLine(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
            if (b.size() > 16384) throw new Exception("header too large");
        }
        if (c == -1 && b.size() == 0) return null;
        return b.toString("UTF-8");
    }

    JSONObject readJson(Http r, int limit) throws Exception {
        int len = Integer.parseInt(r.h.getOrDefault("content-length", "0"));
        if (len > limit) throw new Exception("too large");
        byte[] b = new byte[len];
        int o = 0;
        while (o < len) { int n = r.in.read(b, o, len - o); if (n < 0) break; o += n; }
        return o == 0 ? new JSONObject() : new JSONObject(new String(b, 0, o, StandardCharsets.UTF_8));
    }

    void handle(Socket s) {
        try {
            s.setSoTimeout(120_000);
            Http r = new Http();
            r.in = new java.io.BufferedInputStream(s.getInputStream());
            r.out = new java.io.BufferedOutputStream(s.getOutputStream());
            r.remote = s.getInetAddress().getHostAddress();
            r.remoteLoopback = s.getInetAddress().isLoopbackAddress();
            String line = readLine(r.in);
            if (line == null) return;
            String[] parts = line.split(" ");
            if (parts.length < 2) return;
            r.method = parts[0];
            String target = parts[1];
            int qi = target.indexOf('?');
            r.path = qi < 0 ? target : target.substring(0, qi);
            if (qi >= 0) for (String kv : target.substring(qi + 1).split("&")) {
                int e = kv.indexOf('=');
                if (e > 0) r.q.put(URLDecoder.decode(kv.substring(0, e), "UTF-8"), URLDecoder.decode(kv.substring(e + 1), "UTF-8"));
            }
            String hl;
            while ((hl = readLine(r.in)) != null && !hl.isEmpty()) {
                int c = hl.indexOf(':');
                if (c > 0) r.h.put(hl.substring(0, c).trim().toLowerCase(Locale.ROOT), hl.substring(c + 1).trim());
            }
            r.host = r.h.getOrDefault("host", "").replaceAll(":\\d+$", "");
            route(r);
        } catch (Exception e) {
            // 連線中斷等
        } finally {
            try { s.close(); } catch (Exception ignored) {}
        }
    }

    boolean isLocal(Http r) {
        return r.remoteLoopback && (r.host.equals("localhost") || r.host.equals("127.0.0.1") || r.host.equals("[::1]"));
    }

    void route(Http r) throws Exception {
        String p = r.path, m = r.method;
        boolean remoteRoute = p.equals("/api/hello") || p.equals("/api/request") || p.startsWith("/api/request/") || p.startsWith("/api/upload/");
        try {
            if (remoteRoute) {
                r.cors = true;
                if (m.equals("OPTIONS")) { send(r, 204, "text/plain", new byte[0]); return; }
            }
            Matcher mm;
            if (m.equals("GET") && p.equals("/api/hello")) {
                json(r, 200, new JSONObject().put("app", "pinfile").put("id", id).put("name", name).put("port", port).put("receiving", receiving));
                return;
            }
            if (m.equals("POST") && p.equals("/api/request")) {
                if (!receiving) { err(r, 403, "對方目前沒有開啟接收"); return; }
                JSONObject body = readJson(r, 1_000_000);
                JSONArray arr = body.optJSONArray("files");
                if (arr == null || arr.length() == 0) { err(r, 400, "沒有檔案"); return; }
                int pending = 0;
                for (Req x : requests.values()) if (x.status.equals("pending")) pending++;
                if (pending >= 10) { err(r, 429, "待處理請求過多"); return; }
                Req q = new Req();
                q.id = UUID.randomUUID().toString(); q.from = trunc(body.optString("from", "未知裝置"), 60);
                q.fromIp = r.remote.replace("::ffff:", ""); q.createdAt = System.currentTimeMillis();
                for (int i = 0; i < Math.min(arr.length(), MAX_FILES); i++) {
                    JSONObject fo = arr.getJSONObject(i);
                    FileInfo f = new FileInfo(); f.name = safeName(fo.optString("name", "file")); f.size = Math.max(0, fo.optLong("size", 0));
                    q.files.add(f);
                }
                requests.put(q.id, q);
                json(r, 200, new JSONObject().put("id", q.id));
                return;
            }
            if (m.equals("GET") && (mm = Pattern.compile("^/api/request/([\\w-]+)$").matcher(p)).matches()) {
                Req q = requests.get(mm.group(1));
                if (q == null) err(r, 404, "not found"); else json(r, 200, new JSONObject().put("status", q.status));
                return;
            }
            if (m.equals("GET") && (mm = Pattern.compile("^/api/upload/([\\w-]+)$").matcher(p)).matches()) {
                uploadStatus(r, requests.get(mm.group(1)));
                return;
            }
            if (m.equals("POST") && (mm = Pattern.compile("^/api/upload/([\\w-]+)$").matcher(p)).matches()) {
                upload(r, requests.get(mm.group(1)));
                return;
            }

            if (p.startsWith("/api/") || p.equals("/") || p.equals("/index.html")) {
                if (!isLocal(r)) {
                    if (!p.startsWith("/api/")) { send(r, 200, "text/plain; charset=utf-8", ("PinFile 正在運作。請在該裝置上用 http://localhost:" + port + " 操作。").getBytes(StandardCharsets.UTF_8)); return; }
                    err(r, 403, "僅限本機"); return;
                }
            }
            if (m.equals("GET") && (p.equals("/") || p.equals("/index.html"))) {
                try (InputStream in = ctx.getAssets().open("index.html")) {
                    ByteArrayOutputStream b = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
                    send(r, 200, "text/html; charset=utf-8", b.toByteArray());
                }
                return;
            }
            if (m.equals("GET") && p.equals("/api/info")) {
                JSONArray ips = new JSONArray(); for (String i : localIPs()) ips.put(i);
                json(r, 200, new JSONObject().put("name", name).put("port", port).put("receiving", receiving).put("saveDir", "下載/PinFile（Downloads/PinFile）").put("ips", ips));
                return;
            }
            if (m.equals("GET") && p.equals("/api/peers")) {
                JSONArray a = new JSONArray();
                for (Peer x : peers.values()) a.put(new JSONObject().put("id", x.id).put("name", x.name).put("ip", x.ip).put("port", x.port));
                json(r, 200, a); return;
            }
            if (m.equals("GET") && p.equals("/api/inbox")) {
                List<Req> l = new ArrayList<>(requests.values());
                Collections.sort(l, (a, b) -> Long.compare(b.createdAt, a.createdAt));
                JSONArray a = new JSONArray();
                for (int i = 0; i < Math.min(20, l.size()); i++) a.put(publicReq(l.get(i)));
                json(r, 200, a); return;
            }
            if (m.equals("POST")) {
                if (!"1".equals(r.h.get("x-pinfile"))) { err(r, 403, "bad request"); return; }
                if (p.equals("/api/receiving")) {
                    receiving = readJson(r, 1_000_000).optBoolean("on");
                    announce();
                    if (!receiving) for (Req q : requests.values()) if (q.status.equals("pending")) q.status = "rejected";
                    json(r, 200, new JSONObject().put("receiving", receiving)); return;
                }
                if ((mm = Pattern.compile("^/api/decision/([\\w-]+)$").matcher(p)).matches()) {
                    Req q = requests.get(mm.group(1));
                    if (q == null || !q.status.equals("pending")) { err(r, 404, "請求已失效"); return; }
                    q.status = readJson(r, 1_000_000).optBoolean("accept") ? "accepted" : "rejected";
                    json(r, 200, new JSONObject().put("status", q.status)); return;
                }
            }
            err(r, 404, "not found");
        } catch (Exception e) {
            try { err(r, 500, String.valueOf(e.getMessage())); } catch (Exception ignored) {}
        }
    }

    void uploadStatus(Http r, Req q) throws Exception {
        int idx; try { idx = Integer.parseInt(r.q.getOrDefault("i", "-1")); } catch (Exception e) { idx = -1; }
        if (q == null || idx < 0 || idx >= q.files.size()) { err(r, 404, "not found"); return; }
        if (!q.status.equals("accepted") && !q.status.equals("done")) { err(r, 403, "未授權"); return; }
        FileInfo f = q.files.get(idx);
        json(r, 200, new JSONObject().put("received", f.received).put("size", f.size).put("active", f.active).put("done", f.done));
    }

    // 支援續傳：中斷時保留已寫入的部分（IS_PENDING 檔案），下次從 offset 接續
    void upload(Http r, Req q) throws Exception {
        int idx; try { idx = Integer.parseInt(r.q.getOrDefault("i", "-1")); } catch (Exception e) { idx = -1; }
        FileInfo f = q != null && idx >= 0 && idx < q.files.size() ? q.files.get(idx) : null;
        if (q == null || !q.status.equals("accepted") || f == null || f.done) { err(r, 403, "未授權"); return; }
        long len;
        try { len = Long.parseLong(r.h.getOrDefault("content-length", "-1")); } catch (Exception e) { len = -1; }
        if (len < 0) { err(r, 411, "缺少長度"); return; }
        long offset;
        try { offset = Long.parseLong(r.q.getOrDefault("offset", "0")); } catch (Exception e) { offset = -1; }
        ContentResolver cr = ctx.getContentResolver();
        synchronized (f) {
            if (f.active) { err(r, 403, "未授權"); return; }
            if (offset != f.received) { json(r, 409, new JSONObject().put("error", "位移不符").put("received", f.received)); return; }
            if (offset + len > f.size) { err(r, 413, "檔案大小超出宣告"); return; }
            f.active = true;
        }
        OutputStream os = null;
        try {
            if (f.uri == null) {
                String ext = MimeTypeMap.getFileExtensionFromUrl(f.name.replace(" ", "_"));
                String mime = ext == null ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(Locale.ROOT));
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, f.name);
                cv.put(MediaStore.Downloads.MIME_TYPE, mime == null ? "application/octet-stream" : mime);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, "Download/PinFile");
                cv.put(MediaStore.Downloads.IS_PENDING, 1);
                f.uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (f.uri == null) throw new Exception("無法建立檔案");
                os = cr.openOutputStream(f.uri, "w");
            } else os = cr.openOutputStream(f.uri, "wa");
            byte[] buf = new byte[64 * 1024]; long got = 0;
            while (got < len) {
                int n = r.in.read(buf, 0, (int) Math.min(buf.length, len - got));
                if (n < 0) break;
                os.write(buf, 0, n); got += n; f.received = offset + got;
            }
            os.close(); os = null;
            if (got != len) throw new Exception("傳輸中斷");
            f.received = offset + got;
            if (f.received >= f.size) {
                ContentValues done = new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING, 0);
                cr.update(f.uri, done, null, null);
                f.done = true;
                boolean all = true; for (FileInfo x : q.files) if (!x.done) all = false;
                if (all) q.status = "done";
            }
            json(r, 200, new JSONObject().put("ok", true).put("received", f.received).put("done", f.done));
        } catch (Exception e) {
            try { if (os != null) os.close(); } catch (Exception ignored) {}
            // 以實際寫入磁碟的大小為準，保留部分檔案供續傳
            try (android.os.ParcelFileDescriptor pfd = f.uri == null ? null : cr.openFileDescriptor(f.uri, "r")) {
                f.received = pfd == null ? 0 : pfd.getStatSize();
            } catch (Exception ex) { f.received = 0; }
            try { err(r, 400, String.valueOf(e.getMessage())); } catch (Exception ignored) {}
        } finally {
            f.active = false;
        }
    }
}
