// PinFile - 同 Wi-Fi 單向檔案傳輸（接收方需主動開啟接收並同意）
// 無外部相依，只需 Node.js 18+。用法：node server.js [埠號]
const http = require('http');
const dgram = require('dgram');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.argv[2] || process.env.PORT) || 8787;
const DISCOVERY_PORT = 41234;
const SAVE_DIR = path.resolve(process.env.SAVE_DIR || path.join(__dirname, 'received'));
const NAME = process.env.DEVICE_NAME || os.hostname();
const ID = crypto.randomUUID();
const REQUEST_TTL = 60_000; // 等待接收方回應的時間
const MAX_FILES = 1000;

fs.mkdirSync(SAVE_DIR, { recursive: true });

let receiving = false;
const requests = new Map(); // id -> request
const peers = new Map(); // id -> {id,name,ip,port,seen}

// ---------- 裝置探索（UDP 廣播） ----------
const udp = dgram.createSocket({ type: 'udp4', reuseAddr: true });
udp.on('error', (e) => console.warn('UDP 探索失敗：', e.message));
udp.on('message', (msg, rinfo) => {
  try {
    const m = JSON.parse(msg.toString());
    if (m.app !== 'pinfile' || m.id === ID) return;
    if (m.receiving) peers.set(m.id, { id: m.id, name: String(m.name).slice(0, 60), ip: rinfo.address, port: Number(m.port), seen: Date.now() });
    else peers.delete(m.id);
  } catch {}
});
udp.bind(DISCOVERY_PORT, () => { udp.setBroadcast(true); });

function broadcastTargets() {
  const out = new Set(['255.255.255.255']);
  for (const list of Object.values(os.networkInterfaces())) {
    for (const i of list || []) {
      if (i.family !== 'IPv4' || i.internal) continue;
      const a = i.address.split('.').map(Number), m = i.netmask.split('.').map(Number);
      out.add(a.map((x, k) => (x & m[k]) | (~m[k] & 255)).join('.'));
    }
  }
  return [...out];
}
function announce() {
  const buf = Buffer.from(JSON.stringify({ app: 'pinfile', id: ID, name: NAME, port: PORT, receiving }));
  for (const t of broadcastTargets()) udp.send(buf, DISCOVERY_PORT, t, () => {});
}
setInterval(() => { if (receiving) announce(); }, 2000);
setInterval(() => {
  const now = Date.now();
  for (const [k, p] of peers) if (now - p.seen > 7000) peers.delete(k);
  for (const [k, r] of requests) if (r.status === 'pending' && now - r.createdAt > REQUEST_TTL) r.status = 'expired';
}, 1000);

function localIPs() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces()))
    for (const i of list || []) if (i.family === 'IPv4' && !i.internal) out.push(i.address);
  return out;
}

// ---------- 工具 ----------
function isLocal(req) {
  const a = req.socket.remoteAddress;
  const host = (req.headers.host || '').replace(/:\d+$/, '');
  return (a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1') && (host === 'localhost' || host === '127.0.0.1' || host === '[::1]');
}
function json(res, code, obj) {
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}
function readJson(req, limit = 1_000_000) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString() || '{}')); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}
const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
function safeName(name) {
  let n = path.basename(String(name).replace(/\\/g, '/')).replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/, '').slice(0, 200);
  if (!n || RESERVED.test(n)) n = '_' + n;
  return n || 'file';
}
function openUnique(name) {
  const ext = path.extname(name), base = path.basename(name, ext);
  for (let i = 0; ; i++) {
    const p = path.join(SAVE_DIR, i ? `${base} (${i})${ext}` : name);
    try { return { path: p, fd: fs.openSync(p, 'wx') }; } catch (e) { if (e.code !== 'EEXIST') throw e; }
  }
}
function publicReq(r) {
  return { id: r.id, from: r.from, fromIp: r.fromIp, status: r.status, createdAt: r.createdAt,
    files: r.files.map((f) => ({ name: f.name, size: f.size, received: f.received, done: f.done })) };
}
// 只有「遠端裝置要呼叫」的路由才開放 CORS
function cors(res) {
  res.setHeader('access-control-allow-origin', '*');
  res.setHeader('access-control-allow-headers', 'content-type');
  res.setHeader('access-control-allow-methods', 'GET,POST,OPTIONS');
  res.setHeader('access-control-allow-private-network', 'true');
}

// ---------- HTTP ----------
const INDEX = path.join(__dirname, 'public', 'index.html');

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  const remoteRoute = p === '/api/hello' || p === '/api/request' || p.startsWith('/api/request/') || p.startsWith('/api/upload/');
  try {
    if (remoteRoute) {
      cors(res);
      if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    }

    // 區網掃描用：回報身分與是否在接收
    if (req.method === 'GET' && p === '/api/hello') return json(res, 200, { app: 'pinfile', id: ID, name: NAME, port: PORT, receiving });

    // 給對方裝置呼叫：提出傳送請求
    if (req.method === 'POST' && p === '/api/request') {
      if (!receiving) return json(res, 403, { error: '對方目前沒有開啟接收' });
      const body = await readJson(req);
      const files = Array.isArray(body.files) ? body.files.slice(0, MAX_FILES) : [];
      if (!files.length) return json(res, 400, { error: '沒有檔案' });
      if ([...requests.values()].filter((r) => r.status === 'pending').length >= 10) return json(res, 429, { error: '待處理請求過多' });
      const r = {
        id: crypto.randomUUID(), from: String(body.from || '未知裝置').slice(0, 60),
        fromIp: (req.socket.remoteAddress || '').replace('::ffff:', ''), status: 'pending', createdAt: Date.now(),
        files: files.map((f) => ({ name: safeName(f.name), size: Math.max(0, Number(f.size) || 0), received: 0, done: false, saved: null })),
      };
      requests.set(r.id, r);
      return json(res, 200, { id: r.id });
    }
    let m;
    if (req.method === 'GET' && (m = p.match(/^\/api\/request\/([\w-]+)$/))) {
      const r = requests.get(m[1]);
      return r ? json(res, 200, { status: r.status }) : json(res, 404, { error: 'not found' });
    }
    if (req.method === 'GET' && (m = p.match(/^\/api\/upload\/([\w-]+)$/))) {
      const r = requests.get(m[1]);
      const f = r && r.files[Number(url.searchParams.get('i'))];
      if (!r || !f) return json(res, 404, { error: 'not found' });
      if (r.status !== 'accepted' && r.status !== 'done') return json(res, 403, { error: '未授權' });
      return json(res, 200, { received: f.received, size: f.size, active: !!f.active, done: f.done });
    }
    // 支援續傳：中斷時保留已寫入的部分，下次從 offset（必須等於已收到的位元組數）接續
    if (req.method === 'POST' && (m = p.match(/^\/api\/upload\/([\w-]+)$/))) {
      const r = requests.get(m[1]);
      const f = r && r.files[Number(url.searchParams.get('i'))];
      if (!r || r.status !== 'accepted' || !f || f.done || f.active) return json(res, 403, { error: '未授權' });
      const offset = Number(url.searchParams.get('offset') || 0);
      if (offset !== f.received) return json(res, 409, { error: '位移不符', received: f.received });
      f.active = true;
      let dest = f.saved, out;
      if (!dest) { const o = openUnique(f.name); dest = f.saved = o.path; out = fs.createWriteStream(dest, { fd: o.fd }); }
      else out = fs.createWriteStream(dest, { flags: 'a' });
      let got = 0, failed = false;
      const fail = (code, msg) => {
        if (failed) return; failed = true;
        req.unpipe(out);
        out.once('close', () => { try { f.received = fs.statSync(dest).size; } catch { f.received = 0; } f.active = false; });
        out.destroy();
        if (!res.headersSent) json(res, code, { error: msg });
      };
      req.on('data', (c) => { got += c.length; if (offset + got > f.size) fail(413, '檔案大小超出宣告'); });
      req.on('close', () => { if (!req.complete) fail(499, '傳輸中斷'); });
      req.on('error', () => fail(500, '傳輸錯誤'));
      out.on('error', () => fail(500, '寫入失敗'));
      out.on('finish', () => {
        if (failed) return;
        f.received = offset + got; f.active = false;
        if (f.received >= f.size) f.done = true;
        if (r.files.every((x) => x.done)) { r.status = 'done'; console.log(`已收到 ${r.files.length} 個檔案，來自 ${r.from}`); }
        json(res, 200, { ok: true, received: f.received, done: f.done });
      });
      return req.pipe(out);
    }

    // 以下僅限本機瀏覽器操作
    if (p.startsWith('/api/') || p === '/' || p === '/index.html') {
      if (!isLocal(req)) {
        if (!p.startsWith('/api/')) { res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('PinFile 正在運作。請在該裝置上用 http://localhost:' + PORT + ' 操作。'); }
        return json(res, 403, { error: '僅限本機' });
      }
    }
    if (req.method === 'GET' && (p === '/' || p === '/index.html')) {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
      return fs.createReadStream(INDEX).pipe(res);
    }
    if (req.method === 'GET' && p === '/api/info')
      return json(res, 200, { name: NAME, port: PORT, receiving, saveDir: SAVE_DIR, ips: localIPs() });
    if (req.method === 'GET' && p === '/api/peers')
      return json(res, 200, [...peers.values()].map(({ id, name, ip, port }) => ({ id, name, ip, port })));
    if (req.method === 'GET' && p === '/api/inbox')
      return json(res, 200, [...requests.values()].sort((a, b) => b.createdAt - a.createdAt).slice(0, 20).map(publicReq));

    if (req.method === 'POST') {
      if (req.headers['x-pinfile'] !== '1') return json(res, 403, { error: 'bad request' });
      if (p === '/api/receiving') {
        const b = await readJson(req);
        receiving = !!b.on;
        if (receiving) announce();
        else { announce(); for (const r of requests.values()) if (r.status === 'pending') r.status = 'rejected'; }
        return json(res, 200, { receiving });
      }
      if ((m = p.match(/^\/api\/decision\/([\w-]+)$/))) {
        const r = requests.get(m[1]);
        if (!r || r.status !== 'pending') return json(res, 404, { error: '請求已失效' });
        const b = await readJson(req);
        r.status = b.accept ? 'accepted' : 'rejected';
        return json(res, 200, { status: r.status });
      }
    }
    json(res, 404, { error: 'not found' });
  } catch (e) {
    if (!res.headersSent) json(res, 500, { error: String(e.message || e) });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`PinFile 已啟動：http://localhost:${PORT}`);
  console.log(`裝置名稱：${NAME}　區網位址：${localIPs().map((i) => `${i}:${PORT}`).join(', ') || '(無)'}`);
  console.log(`接收的檔案存放於：${SAVE_DIR}`);
});
server.on('error', (e) => { console.error(e.code === 'EADDRINUSE' ? `埠號 ${PORT} 已被使用，請改用：node server.js 其他埠號` : e); process.exit(1); });
