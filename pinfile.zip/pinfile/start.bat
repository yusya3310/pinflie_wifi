@echo off
chcp 65001 >nul
start "" http://localhost:8787
node "%~dp0server.js"
pause
